# Nutrical AI — Android project

A native Android calorie and macro tracker for common Indian foods.

## Features
- Daily dashboard with 2,300 kcal and macro totals (initial target)
- Food log by meal: Breakfast, Lunch, Snacks, Dinner
- Portion entry in grams and per-100g calorie/protein/carbs/fat estimates
- Persistent local diary using Android SharedPreferences
- Photo picker and on-device ML Kit image labeling; food labels are mapped to a suggested food entry for user confirmation

## Build an APK
1. Install Android Studio (current stable) on a computer with internet access.
2. Open this folder (`NutricalAI`) in Android Studio.
3. Allow Gradle sync and SDK installation (compile SDK 35; Android Gradle Plugin 8.7.3).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
- Food recognition uses ML Kit's general image-labeling model. It may identify a broad label or misidentify mixed dishes; it does not measure portion weight or reliably detect oil/hidden ingredients. Confirm the food and enter its actual weight.
- Nutrition values are approximate reference values per 100 g and vary with recipe, cooking method and brand.
- The app currently uses a fixed 2,300 kcal display goal; edit the source to customize it.
- This source project has not been compiled in this environment because Android SDK/Gradle downloads are unavailable here. No APK is included or claimed as tested.
