package com.nutricalai.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

public class MainActivity extends Activity {
    private final int green=Color.rgb(19,138,91), ink=Color.rgb(31,41,36), muted=Color.rgb(105,116,109), bg=Color.rgb(246,249,247);
    private SharedPreferences prefs; private JSONArray entries=new JSONArray();
    private TextView totals, macros, remaining, photoStatus; private LinearLayout diary;
    private EditText grams; private Spinner foodSpinner, mealSpinner;
    private final String[] foods={"Cooked white rice","Chicken breast (cooked)","Egg","Curd","Idli","Dosa","Chapati","Dal","Sambar","Mixed vegetables","Banana","Apple","Paneer","Oats (dry)","Milk"};
    private final double[][] nutrition={{130,2.7,28.2,.3},{165,31,0,3.6},{155,13,1.1,11},{98,3.5,4.7,5},{58,2,12,.4},{168,4,27,5},{297,9,50,7},{116,7.5,20,1},{60,3,9,1.5},{65,2.5,10,2},{89,1.1,22.8,.3},{52,.3,14,.2},{265,18,1.2,21},{389,16.9,66.3,6.9},{61,3.2,4.8,3.3}};
    private final String[] meals={"Breakfast","Lunch","Snacks","Dinner"};
    private static class Item {String name,meal; double g,kcal,p,c,f; Item(String n,String m,double grams,double[] v){name=n;meal=m;g=grams;kcal=v[0]*grams/100;p=v[1]*grams/100;c=v[2]*grams/100;f=v[3]*grams/100;}}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.WHITE);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);prefs=getSharedPreferences("nutrical",MODE_PRIVATE);load();build();}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void pad(View v,int n){v.setPadding(n,n,n,n);}
    private android.graphics.drawable.GradientDrawable shape(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    private TextView button(String label){TextView b=text(label,15,Color.WHITE,true);b.setGravity(Gravity.CENTER);b.setPadding(16,14,16,14);b.setBackground(shape(green,24));return b;}
    private void build(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);LinearLayout root=column();root.setPadding(18,18,18,30);root.setBackgroundColor(bg);scroll.addView(root);setContentView(scroll);
        LinearLayout brand=row();TextView title=text("Nutrical AI",27,ink,true);brand.addView(title);TextView tag=text("  FOOD & NUTRITION",10,green,true);brand.addView(tag);root.addView(brand);root.addView(text("Your daily food tracker",14,muted,false));
        LinearLayout card=column();card.setPadding(18,18,18,18);card.setBackground(shape(Color.WHITE,24));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=20;root.addView(card,cp);
        card.addView(text("DAILY CALORIE GOAL",11,muted,true));totals=text("0 / 2300 kcal",28,green,true);card.addView(totals);remaining=text("2300 kcal remaining",14,muted,false);card.addView(remaining);macros=text("Protein 0g     Carbs 0g     Fat 0g",13,ink,true);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2);mp.topMargin=14;card.addView(macros,mp);
        TextView addTitle=text("Add food",20,ink,true);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=24;root.addView(addTitle,tp);
        foodSpinner=new Spinner(this);foodSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,foods));root.addView(foodSpinner);
        mealSpinner=new Spinner(this);mealSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,meals));root.addView(mealSpinner);
        grams=new EditText(this);grams.setSingleLine(true);grams.setInputType(2);grams.setHint("Quantity in grams (e.g. 150)");root.addView(grams);
        TextView add=button("+  Add to diary");LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=8;root.addView(add,ap);add.setOnClickListener(v->addFood());
        TextView photoTitle=text("Scan a food photo",20,ink,true);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2);pp.topMargin=24;root.addView(photoTitle,pp);root.addView(text("Choose a meal photo. On-device AI will identify likely food labels; confirm the food and portion before logging.",13,muted,false));
        TextView photo=button("📷  Choose food photo");LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=10;root.addView(photo,bp);photo.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("image/*");startActivityForResult(Intent.createChooser(i,"Select meal photo"),41);});
        photoStatus=text("Photo analysis has not been run.",13,muted,false);root.addView(photoStatus);
        TextView d=text("Today's food diary",20,ink,true);LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,-2);dp.topMargin=24;root.addView(d,dp);diary=column();root.addView(diary);render();
        root.addView(text("Estimates are approximate. Photo recognition cannot determine exact portion size, oil or hidden ingredients. Review every suggestion.",11,muted,false));
    }
    private void addFood(){try{double g=Double.parseDouble(grams.getText().toString());if(g<=0)throw new Exception();int ix=foodSpinner.getSelectedItemPosition();Item x=new Item(foods[ix],meals[mealSpinner.getSelectedItemPosition()],g,nutrition[ix]);JSONObject o=new JSONObject();o.put("name",x.name);o.put("meal",x.meal);o.put("g",x.g);o.put("k",x.kcal);o.put("p",x.p);o.put("c",x.c);o.put("f",x.f);entries.put(o);save();grams.setText("");render();}catch(Exception e){Toast.makeText(this,"Enter a valid quantity in grams",Toast.LENGTH_SHORT).show();}}
    private void render(){double k=0,p=0,c=0,f=0;diary.removeAllViews();for(int i=0;i<entries.length();i++){JSONObject o=entries.optJSONObject(i);if(o==null)continue;k+=o.optDouble("k");p+=o.optDouble("p");c+=o.optDouble("c");f+=o.optDouble("f");}
        totals.setText(String.format(Locale.getDefault(),"%.0f / 2300 kcal",k));remaining.setText(String.format(Locale.getDefault(),"%.0f kcal remaining",2300-k));macros.setText(String.format(Locale.getDefault(),"Protein %.0fg     Carbs %.0fg     Fat %.0fg",p,c,f));
        for(String meal:meals){LinearLayout section=column();TextView head=text(meal,16,green,true);section.addView(head);double sub=0;for(int i=0;i<entries.length();i++){JSONObject o=entries.optJSONObject(i);if(o==null||!meal.equals(o.optString("meal")))continue;sub+=o.optDouble("k");LinearLayout r=row();LinearLayout info=column();info.addView(text(o.optString("name"),14,ink,true));info.addView(text(String.format(Locale.getDefault(),"%.0fg · %.0f kcal · P %.1fg",o.optDouble("g"),o.optDouble("k"),o.optDouble("p")),12,muted,false));r.addView(info,new LinearLayout.LayoutParams(0,-2,1));TextView del=text("✕",18,Color.RED,true);r.addView(del);final int index=i;del.setOnClickListener(v->{JSONArray n=new JSONArray();for(int j=0;j<entries.length();j++)if(j!=index)n.put(entries.opt(j));entries=n;save();render();});section.addView(r);}
            if(sub>0){section.addView(text(String.format(Locale.getDefault(),"Subtotal: %.0f kcal",sub),12,muted,false));diary.addView(section);}}
    }
    private void save(){prefs.edit().putString("entries",entries.toString()).apply();}private void load(){try{entries=new JSONArray(prefs.getString("entries","[]"));}catch(Exception e){entries=new JSONArray();}}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req!=41||result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();photoStatus.setText("Analyzing image…");try{InputImage image=InputImage.fromFilePath(this,uri);ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(image).addOnSuccessListener(labels->{String best="";float score=0;for(ImageLabel l:labels){if(l.getConfidence()>score){score=l.getConfidence();best=l.getText();}}String mapped=mapLabel(best);photoStatus.setText("AI label: "+best+" ("+Math.round(score*100)+"%). Suggested match: "+mapped+". Select the correct food and enter its weight above to log it.");for(int i=0;i<foods.length;i++)if(foods[i].equals(mapped)){foodSpinner.setSelection(i);break;}}).addOnFailureListener(e->photoStatus.setText("Could not analyze this photo. Try a clearer, well-lit image."));}catch(Exception e){photoStatus.setText("Unable to open this image.");}}
    private String mapLabel(String s){String x=s.toLowerCase(Locale.ROOT);if(x.contains("rice"))return "Cooked white rice";if(x.contains("chicken"))return "Chicken breast (cooked)";if(x.contains("egg"))return "Egg";if(x.contains("yogurt")||x.contains("curd"))return "Curd";if(x.contains("idli"))return "Idli";if(x.contains("dosa"))return "Dosa";if(x.contains("bread")||x.contains("chapati")||x.contains("flatbread"))return "Chapati";if(x.contains("lentil")||x.contains("dal"))return "Dal";if(x.contains("banana"))return "Banana";if(x.contains("apple"))return "Apple";if(x.contains("milk"))return "Milk";if(x.contains("vegetable"))return "Mixed vegetables";if(x.contains("oat"))return "Oats (dry)";return "Cooked white rice";}
}
